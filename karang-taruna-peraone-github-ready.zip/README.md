# Karang Taruna PERAONE

Website statis Karang Taruna PERAONE — Pule, Selogiri, Wonogiri.

## Struktur
- `index.html` — halaman utama
- `assets/images/logo.jpg` — logo PERAONE
- `assets/images/galeri-1.jpg` sampai `galeri-5.jpg` — foto galeri

## Cara memasang di GitHub Pages
1. Buat repository baru di GitHub, misalnya `karang-taruna-peraone`.
2. Upload seluruh isi folder ini ke repository (jangan upload folder pembungkusnya).
3. Buka **Settings → Pages**.
4. Pada **Build and deployment**, pilih **Deploy from a branch**.
5. Pilih branch `main` dan folder `/ (root)`, lalu **Save**.
6. Tunggu proses deployment selesai. GitHub akan menampilkan alamat Pages repository tersebut.

Website ini menggunakan HTML/CSS/JavaScript biasa, sehingga tidak membutuhkan Node.js atau server backend.
